import { useEffect, useState } from 'react';
import { Trash2, Mail, Archive, Eye } from 'lucide-react';
import toast from 'react-hot-toast';
import api from '../../utils/api';
import { useRole } from '../../hooks/useRole';
import DataTable from './components/DataTable';

export default function ContactManager() {
  const { canDelete } = useRole();
  const [items, setItems] = useState([]);
  const load = () => api.get('/admin/contacts').then(r => setItems(r.data.data || []));
  useEffect(() => { load(); }, []);

  const updateStatus = async (id, status) => {
    await api.patch(`/admin/contacts/${id}`, { status });
    toast.success('Updated'); load();
  };
  const del = async (id) => { if (!confirm('Delete?')) return; await api.delete(`/admin/contacts/${id}`); toast.success('Deleted'); load(); };

  return (
    <div className="space-y-6">
      <h2 className="text-h2">Contact Submissions</h2>
      <DataTable data={items} columns={[
        { key: 'name', label: 'Name', render: c => <span className="font-medium">{c.name}</span> },
        { key: 'email', label: 'Email' },
        { key: 'subject', label: 'Subject', render: c => <span className="line-clamp-1">{c.subject}</span> },
        { key: 'status', label: 'Status', render: c => {
          const colors = { new: 'badge-blue', read: 'badge-orange', replied: 'badge-green', archived: '' };
          return <span className={`badge ${colors[c.status] || ''}`}>{c.status}</span>;
        }},
        { key: 'createdAt', label: 'Date', render: c => new Date(c.createdAt).toLocaleDateString() },
      ]} searchFields={['name', 'email', 'subject']} searchPlaceholder="Search contacts..."
        actions={(c) => (<>
          <button onClick={() => updateStatus(c._id, 'read')} title="Mark Read" aria-label="Mark read" className="p-1.5 rounded-btn hover:bg-light-card dark:hover:bg-dark-border transition-colors duration-150"><Eye className="w-4 h-4" aria-hidden="true" /></button>
          <button onClick={() => updateStatus(c._id, 'replied')} title="Mark Replied" aria-label="Mark replied" className="p-1.5 rounded-btn hover:bg-light-card dark:hover:bg-dark-border transition-colors duration-150"><Mail className="w-4 h-4" aria-hidden="true" /></button>
          <button onClick={() => updateStatus(c._id, 'archived')} title="Archive" aria-label="Archive" className="p-1.5 rounded-btn hover:bg-light-card dark:hover:bg-dark-border transition-colors duration-150"><Archive className="w-4 h-4" aria-hidden="true" /></button>
          {canDelete && <button onClick={() => del(c._id)} aria-label="Delete submission" className="p-1.5 rounded-btn hover:bg-error-tint dark:hover:bg-red-900/20 text-error transition-colors duration-150"><Trash2 className="w-4 h-4" aria-hidden="true" /></button>}
        </>)}
      />
    </div>
  );
}
